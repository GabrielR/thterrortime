<aside class="mh-sidebar">
	<?php dynamic_sidebar('global-sidebar'); ?>
</aside>