<?php $mh_squared_options = mh_squared_theme_options();
if ($mh_squared_options['comments_pages'] == 'enable') {
	comments_template();
} ?>